import { Accounts } from './accounts';

describe('Accounts', () => {
  it('should create an instance', () => {
    expect(new Accounts()).toBeTruthy();
  });
});
