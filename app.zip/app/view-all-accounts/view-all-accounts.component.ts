import { Component, OnInit } from '@angular/core';
import { AccountsService } from '../accounts.service';
import { Accounts } from '../accounts';

@Component({
  selector: 'app-view-all-accounts',
  templateUrl: './view-all-accounts.component.html',
  styleUrls: ['./view-all-accounts.component.css']
})
export class ViewAllAccountsComponent implements OnInit {

  accounts : Array<Accounts> = [];
  accountsService : AccountsService;

  constructor(accountsService : AccountsService) {
    this.accountsService = accountsService;
   }

  ngOnInit() {
    this.accounts = this.accountsService.getAllAccounts();
  }

}
