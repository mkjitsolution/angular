import { Injectable } from '@angular/core';
import { Accounts } from './accounts';

@Injectable({
  providedIn: 'root'
})
export class AccountsService {

  accounts : Array<Accounts>= [];

  constructor() { 
    let a1 = new Accounts('ashish',2000,9654144814,'ashish@gmail.com');
    let a2 = new Accounts('ramesh',2000,9654144815,'ramesh@gmail.com');
    this.accounts.push(a1);
    this.accounts.push(a2);
  }

  addAccounts(a:Accounts)
  {
    this.accounts.push(a);
  }

  getAllAccounts()
  {
    return this.accounts;
  }

}//end class
