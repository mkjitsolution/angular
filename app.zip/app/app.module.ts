import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ViewAllAccountsComponent } from './view-all-accounts/view-all-accounts.component';
import { AccountsService } from './accounts.service';
import { AddAccountsComponent } from './add-accounts/add-accounts.component';
import {FormsModule} from '@angular/forms';
import { SearchAccountComponent } from './search-account/search-account.component';

@NgModule({
  declarations: [
    AppComponent,
    ViewAllAccountsComponent,
    AddAccountsComponent,
    SearchAccountComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [AccountsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
